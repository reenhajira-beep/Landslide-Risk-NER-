export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000';
export type Risk = 'LOW'|'MODERATE'|'HIGH'|'CRITICAL';
export type Zone = {name:string; state:string; rainfall:number; moisture:number; tilt:number; vegetation:number; satellite:number; score:number; lat:number; lng:number};
export const riskOf=(score:number):Risk=>score>75?'CRITICAL':score>50?'HIGH':score>25?'MODERATE':'LOW';
export const zones:Zone[]=[
 {name:'Cherrapunji',state:'Meghalaya',rainfall:45.2,moisture:94,tilt:42,vegetation:-18,satellite:88,score:89,lat:25.27,lng:91.73},
 {name:'Sikkim North',state:'Sikkim',rainfall:28.4,moisture:82,tilt:38,vegetation:-9,satellite:71,score:74,lat:27.65,lng:88.47},
 {name:'Tawang',state:'Arunachal Pradesh',rainfall:19.7,moisture:73,tilt:35,vegetation:-5,satellite:55,score:53,lat:27.59,lng:91.86},
 {name:'Aizawl',state:'Mizoram',rainfall:12.1,moisture:61,tilt:28,vegetation:-2,satellite:42,score:41,lat:23.73,lng:92.72},
 {name:'Imphal',state:'Manipur',rainfall:8.9,moisture:56,tilt:18,vegetation:1,satellite:29,score:28,lat:24.82,lng:93.95},
 {name:'Kohima',state:'Nagaland',rainfall:5.3,moisture:44,tilt:22,vegetation:2,satellite:18,score:18,lat:25.67,lng:94.11}
];
async function request<T>(path:string, init?:RequestInit):Promise<T>{const r=await fetch(`${API_URL}${path}`,init);if(!r.ok)throw new Error(`Request failed (${r.status})`);return r.json()}
export const api={health:()=>request('/health'),predictions:()=>request('/api/predictions'),alerts:()=>request('/api/alerts'),reports:()=>request('/api/community-reports'),predict:(data:unknown)=>request('/api/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),submitReport:(data:unknown)=>request('/api/community-reports',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)})};
