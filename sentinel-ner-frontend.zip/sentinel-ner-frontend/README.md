# Sentinel-NER frontend

React + TypeScript command-centre UI for the Sentinel-NER landslide early-warning system.

1. Copy `.env.example` to `.env` and set `VITE_API_URL` if your API is elsewhere.
2. Run `npm install`.
3. Run `npm run dev`.

The UI uses local demo data when the API is unavailable. API calls are centralized in `src/services/api.ts`.
